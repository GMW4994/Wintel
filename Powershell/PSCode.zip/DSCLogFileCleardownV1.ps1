﻿<#
 Script Title:     DSCLogFileCleardownV1.ps1
       
 Author:           Gary Wells  
 
 Creation Date:    25th July 2017

 Version:          1.0

 Revision History:

 Gary Wells        10th August 2017
 Added logging output to C:\Windows\Build\Logs\ on target server
 Retention Time set to 7 days
 Removed Days From Today calculator function used for testing
 Added highlight to screen output for clarity
   
   
#>   
    # 
    # This script will locate all .MOF and .JSON files relating to DSC and remove all but the last 7 days
    # This value can be changed by modifying the $RetentionTimeInDays parameter below
    #
$RetentionTimeInDays = 7
    #
    # The operator will be asked to input the name of the remote host to clear down
    #
$Computername = read-host -prompt 'Please enter the Hostname of the server that you wish to clear down'
    #
    # Elevated Credentials will be required before any files can be enumerated or cleared down
    #
$creds = Get-Credential -Message 'Enter Elevated User Credentials to proceed'
if(-not($creds)){EXIT}
    # 
    # The script will search the path C:\Windows\System32\Configuration\ConfigurationStatus\ on the selected host for all files
    # Logic will then determine how many files are older than the specified Retention Time above
    #
[array]$files = invoke-command -ComputerName $Computername -ScriptBlock `
{
    $RetentionTimeInDays = $args[0]
    Get-ChildItem 'C:\windows\System32\Configuration\ConfigurationStatus' | Where-Object {$_.Creationtime -lt (get-date).AddDays(-$RetentionTimeInDays)} 
} -ArgumentList $RetentionTimeInDays
    #
    # The number of files that can de deleted will be returned
    #
$filecount = $files.Count
    # 
    # If there are files to delete, a message is displayed with the number of eligible files that can be deleted
    #
if ($filecount -ge 1) {
        #
        # The operator must then confirm he or she wishes to proceed and cleanse the folder
        # Only YES will result in the deletions being processed. Any other key / phrase will exit the script. 
        # This value is NOT case-sensitive as all input values will be forced to Upper Case
        #   
    $response = read-host -Prompt "$ComputerName contains $filecount file(s) older than $RetentionTimeInDays days. Would you like to delete them? (Type YES to confirm)"
    if(($response.ToUpper()) -ne "YES") {Write-Host -backgroundcolor yellow -ForegroundColor black "Process Aborted by Operator. Re-run the script if you wish to clear down the eligible files"; EXIT}
        #
        # The script will then clear all of the eligible files and return a confirmation
        #     
    $filedelete = invoke-command -ComputerName $Computername -ScriptBlock `
{
    #
    # A Log file will be created and stored on the target server with the number of files deleted
    #
 $DateCompact = get-date -Format "yyyMMdd_HHmmss"
 $LogTranscriptPath = "C:\Windows\Build\Logs\DSCLogsCleared_$DateCompact.txt"
 Start-Transcript -Path $LogTranscriptPath -NoClobber
    #
 $RetentionTimeInDays = $args[0]
 $filecount = $args[1]
 $computername = $args[2]
 Get-ChildItem 'C:\windows\System32\Configuration\ConfigurationStatus' | Where-Object {$_.Creationtime -lt (get-date).AddDays(-$RetentionTimeInDays)} | Remove-Item -Force
 Write-Host -backgroundcolor green -ForegroundColor black "Deleted $filecount files from $Computername"
 Stop-Transcript
    } -ArgumentList $RetentionTimeInDays,$filecount,$Computername
}
else {
    #
    # If there are NO eligible files to delete, a message is displayed stating there are zero files to delete and the script will exit
    #
    Write-Host -backgroundcolor green -ForegroundColor black "There are zero files to delete from $Computername"
}