﻿<#
 Script Title:     EventLogCleardown.ps1
       
 Author:           Gary Wells  
 
 Creation Date:    25th July 2017

 Revision History:
   
   
#>   
    # 
    # This script will clear down selected Event Logs on a target host
    # Only APPLICATION, SYSTEM & SECURITY Event Logs can be targeted
    # Log Files will be tested against a Maximum size value of 999MB
    # Log files exceeding this size can be cleared down
    #
$MaxLogFileSizeInBytes = 1047527424
    #
    # The operator will be asked to input the name of the remote host to clear down
    #
$Computername = read-host -prompt 'Please enter the Hostname of the server that you wish to clear down'
    #
    # The script will search the remote host for the 3 applicable Event Logs and return the sizes
    #
$LogDetails = invoke-command -ComputerName $Computername -ScriptBlock `
{
    Get-WmiObject -Class win32_nteventlogfile | Where-Object {$_.name -match "Security.evt?" -or $_.name -match "System.evt?" -or $_.name -match "Application.evt?"} 
}
    #
    # The Event Log details will be returned
    #
Write-Host "The Event Log details for $Computername are" 
$LogDetails | select Filesize,logfilename,name,numberofrecords | ft | Out-String | %{Write-Host $_}
    #
$SecurityLogDetails = $LogDetails | where{$_.LogFileName -eq "Security"}
$SystemLogDetails = $LogDetails | where{$_.LogFileName -eq "System"}
$ApplicationLogDetails = $LogDetails | where{$_.LogFileName -eq "Application"}
    #
    # Logic will then determine if any of the logs need to to be cleared down (Those of 999MB or more)
    #
if ($SecurityLogDetails.FileSize -ge $MaxLogFileSizeInBytes)
{
Write-Host "The $Computername Security Log File can be cleared down"
Read-Host -Prompt "Would you like to delete this Log File? (Type YES to confirm)"
    if(($response.ToUpper()) -ne "YES"){EXIT}

}
else
{
Write-Host "The Security Log file is currently below the Maximum Size allowed"
}
    #
if ($SystemLogDetails.FileSize -ge $MaxLogFileSizeInBytes)
{
Write-Host "The $Computername System Log File can be cleared down"
Read-Host -Prompt "Would you like to delete this Log File? (Type YES to confirm)"

    if(($response.ToUpper()) -ne "YES"){EXIT}
}
else
{
Write-Host "The System Log file is currently below the Maximum Size allowed"
}
    #
if ($ApplicationLogDetails.FileSize -ge $MaxLogFileSizeInBytes)
{
Write-Host "The $Computername Application Log File can be cleared down"
Read-Host -Prompt "Would you like to delete this Log File? (Type YES to confirm)"
    if(($response.ToUpper()) -ne "YES"){EXIT}
}
else
{
Write-Host "The Application Log file is currently below the Maximum Size allowed"
}
