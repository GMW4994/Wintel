
<# 
  
  Script Title:     CleanUp.ps1 
         
  Author:           Gary Wells   
   
  Creation Date:    23rd August 2017 
  
  Version:          1.0 
  
  Revision History: 
  
  
  
      
 #>   
 
 <# 

  This script will clear down Event Logs and DSC log files on a host and will be launched as a daily Scheduled Task
  The criteria is set using variables in the Variable Block section below:

  Variables and their uses are described here:
	 
    $RetentionTimeInDays is the number of days to KEEP MOF and JSON files
    
	$MaxAuditLogSize is the value that should be set for the 3 Administrative Log Files (1GB)
     
    $TriggerAuditLogArchive is the value at which a log file will be considered for archiving
    
    $OversizeAuditLogFileSze is the value at which a log file will NOT be archived - it will automatically be cleared down

    $ArchiveLogFileStoragePath is the location to store all archived log files

    $LogTranscriptPath is the location to store all transcript log files

    $DateCompact sets the format of the dat output appended to files

    $TaskExists tests to see if a Scheduled Task with the given name already exists
    
	
#>

    ##################
    # Variable Block #
    ##################

$RetentionTimeInDays = 7
$MaxAuditLogFileSize = 1GB
$TriggerAuditLogArchive = 50KB
$OversizeAuditLogFileSize =60KB
$ArchiveLogFileStoragePath = "C:\Windows\System32\Winevt\Archive"
$LogTranscriptPath = "C:\Windows\System32\Winevt\Archive"
$DateCompact = get-date -Format "yyyMMdd_HHmmss"
$TaskExists = Get-ScheduledTask -TaskName "Daily Log Cleanup"

Start-Transcript -Path $LogTranscriptPath\CleanupLog_$datecompact.txt -NoClobber
        Write-Host "***********************************************************************************************"
        Write-Host "***********************************************************************************************"
        Write-Host "Checking for an existing Scheduled Task on $env:computername..."
        Write-Host "***********************************************************************************************"
        Write-Host "***********************************************************************************************"

    #########################
    # Create Scheduled Task #
    #########################
    #
    # This section of the script check for an existing Scheduled Task called Daily Log Cleanup
    # If there is no existing Scheduled Task, one will be created and registered
    #
    # The Scheduled Task will be created in \Microsoft\Windows\LogFile Cleanup folder of the Task Scheduler Library
    # The Task is called Daily Log Cleanup
    # The task will run at 02:00 daily, with a 1 hour randomisation factor built in
    #
    # The Task Action is to run C:\Scripts\CleanUp.ps1 using SYSTEM account
    #
   
    if ($TaskExists.TaskName -ne "Daily Log Cleanup")  {

$Action = New-ScheduledTaskAction -Execute "C:\Windows\System32\WindowsPowerShell\v1.0\Powershell.exe" -Argument "-NonInteractive -NoLogo -NoProfile -File C:\Scripts\Cleanup.ps1"
$Trigger = New-ScheduledTaskTrigger -At "02:00" -Daily -RandomDelay (New-TimeSpan -Minutes 60)
$Settings = New-ScheduledTaskSettingsSet
Register-ScheduledTask -Action $action -TaskName "Daily Log Cleanup" -Description "This script will clear down Event Logs and DSC log files on a host and will be launched as a Scheduled Task. The Scheduled Task will run Daily at 02:00 with a 1 hour randomisation applied" -RunLevel Highest -Settings $settings -TaskPath "Microsoft\Windows\LogFile CleanUp" -Trigger $trigger -User System
        Write-Host "***********************************************************************************************"
        Write-Host "***********************************************************************************************"
        Write-Host "Created New Scheduled Task Daily Log Cleanup on $env:computername..."
        Write-Host "The New Scheduled Task is set to run Daily at 02:00 witn up to 1 hour random delay"
        Write-Host "***********************************************************************************************"
        Write-Host "***********************************************************************************************"
                                
                                }

    

    ##############################
    # DSC and MOF File Clearance #
    ##############################
    #
    # This section of the script will locate all .MOF and .JSON files relating to DSC and remove all but the last 7 days
    # This value can be changed by modifying the $RetentionTimeInDays parameter in the Variable Block above
    #
    # The script will search the path C:\Windows\System32\Configuration\ConfigurationStatus\ on the host for all files
    # Logic will then determine how many files are older than the specified Retention Time above
    #
    # A Log file will be created and stored on the target server(s) with a verbose output of commands performed
    #

        Write-Host "***********************************************************************************************"
        Write-Host "***********************************************************************************************"
        Write-Host "Scanning DSC Processing Log Repository on $env:computername..."
        WWrite-Host "***********************************************************************************************"
        Write-Host "***********************************************************************************************"
$files = Get-ChildItem 'C:\windows\System32\Configuration\ConfigurationStatus' | Where-Object {$_.Creationtime -lt (get-date).AddDays(-$RetentionTimeInDays)} 
    #
    # The number of files that can de deleted will be returned
    #
$filecount = $files.Count
    # 
    # If there are files to delete, a message is displayed with the number of eligible files that can be deleted
    #
if ($filecount -ge 1) {
        
        #
        # The script will then clear all of the eligible files and return a confirmation
        #     
    $filedelete = Get-ChildItem 'C:\windows\System32\Configuration\ConfigurationStatus' | Where-Object {$_.Creationtime -lt (get-date).AddDays(-$RetentionTimeInDays)} | Remove-Item -Force
        Write-Host "Deleted $filecount DSC Processing files from $ENV:computername"
        Write-Host "***********************************************************************************************"
        Write-Host "***********************************************************************************************"
 }
else {
    #
    # If there are NO eligible files to delete, a message is displayed stating there are zero files to delete and the script will process Event Logs
    #
        Write-Host "There are zero DSC Processing files to delete from $ENV:computername"
        Write-Host "***********************************************************************************************"
        Write-Host "***********************************************************************************************"
}

    #########################################
    # Administrative Event Log Housekeeping #
    #########################################
    #
    # This section of the script will test the size of the 3 Administrative Event Logs 
    # 
    # The first action in the script is to identify any logs over 2GB. These will be summarily cleared down (NO Archive)
    #
    # All remaining logs will now be under 2GB so the next action identifies those that are over 1GB
    # This satisfies the criteria for archiving all logs that are sized between 1GB and 2GB
    #
    # Any eligible logs will be processed as per the following:
    # 1)  Test for the existence of the target repository and create it if required
    # 2)  Check for sufficient disk space to create an archive
    # 3)  Test for existing archive. Delete if they exist
    # 4)  Create new archive
    # 5)  Cleardown log file
    #
$PathExists = Test-Path -path "C:\Windows\System32\Winevt\Archive"
if ($PathExists -eq $false) 
        {
        New-Item -path "C:\Windows\System32\Winevt" -name "Archive" -ItemType "Directory" 
        }
    #
    # This path will be used to store all output logs and the archived event logs if created
    #
    # Archived Audit Logs will be named as "Archive_%LOGFILENAME%_YYYMMDD_HHMMSS"
    #
    # APPLICATION, SYSTEM & SECURITY Event Logs will be targeted
    # 
    # Log files OVER 2GB will be cleared down automatically
    #
$cleardownseclogs = Get-WmiObject -Class win32_nteventlogfile | Where-Object {$_.name -match "Security.evt?" -or $_.name -match "System.evt?" -or $_.name -match "Application.evt?" -and $_.filesize -ge $OversizeAuditLogFileSize}  
$cleardownseclogs | Out-Host
$cleardownseclogs | ForEach-Object {
                          Clear-EventLog -log $_.LogFileName -Verbose | Out-Host
                          Write-Host "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"
                          Write-Host "@@  No backup of this log file was taken as the filesize exceeded the limit for archiving  @@"
                          Write-Host "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"
                                   }
    # 
    # Log files between 1GB and 2GB will be saved before clearing down as long as there is sufficient disk space
    #
    # Each log file will be tested individually as enough disk space to hold the archive must be available for each
    #
    # Log files under 1GB will be ignored
    # 
    ################
    # Security Log #
    ################
    #
    # Check for available disk space
    #
$freespacesec = Get-WmiObject Win32_logicaldisk -filter "deviceid = 'C:'" -computername localhost
    #
    # If the available disk space is more than the filesize of the Security log the cleardown section is triggered
    #
    # If there is an existing Archive of the Security log, this will be deleted 
    # The current Security log will be archived with time and date appended
    # The current Security log will then be cleared down
    # 
            Write-Host "***********************************************************************************************"
            Write-Host "***********************************************************************************************"
            Write-Host "Processing $ENV:computername Security log"
$archiveseclogs_security = Get-WmiObject -Class win32_nteventlogfile | Where-Object {$_.name -match "Security.evt?"} 
$archiveseclogs_security.filesize | Out-Host
    #
if($archiveseclogs_security.filesize -gt $TriggerAuditLogArchive){
    if ($freespacesec.freespace -gt $archiveseclogs_security.filesize) {
        Get-ChildItem -Path $ArchiveLogFileStoragePath | ?{$_.Name -like "Archive_Security*"} | Remove-Item
            Write-Host "The Previous Security log archive was deleted"
        $archiveseclogs_security.BackupEventLog("$ArchiveLogFileStoragePath\Archive_Security_$datecompact.evtx")
            Write-host "The Current Security log was successfully archived to $ArchiveLogFileStoragePath\Archive_Security_$datecompact.evtx"
        Clear-EventLog -logname Security -Verbose
            Write-Host "The $ENV:computername Security log was successfully cleared down"
            Write-Host "***********************************************************************************************"
            Write-Host "***********************************************************************************************"
    }
    else
    {
        Write-Host "The Security Log on $ENV:computername could not be archived at this time as there is not enough free disk space"
    }  
}
else
{
     Write-Host "The Security Log on $ENV:computername does not need to be Archived at this time as it is below 1GB"
}
    #
    #
    ##############
    # System Log #
    ##############
    #
    # Check for available disk space - this may have changed if Security was archived
    #
$freespacesys = Get-WmiObject Win32_logicaldisk -filter "deviceid = 'C:'" -computername localhost
    #
    # If the available disk space is more than the filesize of the Security log the cleardown section is triggered
    #
    # If there is an existing Archive of the System log, this will be deleted 
    # The current System log will be archived with time and date appended
    # The current System log will then be cleared down
    #
            Write-Host "Processing $ENV:computername System log"
$archiveseclogs_system = Get-WmiObject -Class win32_nteventlogfile | Where-Object {$_.name -match "System.evt?"} 
$archiveseclogs_system.filesize | Out-Host
if($archiveseclogs_system.filesize -gt $TriggerAuditLogArchive){
    if ($freespacesys.freespace -gt $archiveseclogs_system.filesize) {
        Get-ChildItem -Path $ArchiveLogFileStoragePath | ?{$_.Name -like "Archive_System*"} | Remove-Item
            Write-Host "The Previous System logfile archive was deleted"
        $archiveseclogs_system.BackupEventLog("$ArchiveLogFileStoragePath\Archive_System_$datecompact.evtx")
            Write-host "The Current System log was successfully archived to $ArchiveLogFileStoragePath\Archive_System_$datecompact.evtx"
        Clear-EventLog -logname System -Verbose
            Write-Host "The $ENV:computername System log was successfully cleared down"
            Write-Host "***********************************************************************************************"
            Write-Host "***********************************************************************************************"
    }
    else
    {
        Write-Host "The System Log on $ENV:computername could not be archived at this time as there is not enough free disk space"
    }
}
else
{
     Write-Host "The System Log on $ENV:computername does not need to be Archived at this time as it is below 1GB"
}
    #
    #
    ###################
    # Application Log #
    ###################
    #
    # Check for available disk space - this may have changed if Security and/or System were archived
    #
$freespaceapp = Get-WmiObject Win32_logicaldisk -filter "deviceid = 'C:'" -computername localhost
    #
    # If the available disk space is more than the filesize of the Application log the cleardown section is triggered
    #
    # If there is an existing Archive of the Application log, this will be deleted 
    # The current Application log will be archived with time and date appended
    # The current Application log will then be cleared down
    #
            Write-Host "Processing $ENV:computername Application log"
$archiveseclogs_Application = Get-WmiObject -Class win32_nteventlogfile | Where-Object {$_.name -match "Application.evt?"} 
$archiveseclogs_Application.filesize | Out-Host
if($archiveseclogs_Application.filesize -gt $TriggerAuditLogArchive){
    if ($freespaceapp.freespace -gt $archiveseclogs_Application.filesize) {
        Get-ChildItem -Path $ArchiveLogFileStoragePath | ?{$_.Name -like "Archive_Application*"} | Remove-Item
            Write-Host "The existing Application log archive was deleted"
        $archiveseclogs_Application.BackupEventLog("$ArchiveLogFileStoragePath\Archive_Application_$datecompact.evtx")
            Write-host "The $ENV:computername Applcation log was successfully archived to $ArchiveLogFileStoragePath\Archive_Application_$datecompact.evtx"
        Clear-EventLog -logname Application -Verbose
            Write-Host "The $ENV:computername Application log was successfully cleared down"
            Write-Host "***********************************************************************************************"
            Write-Host "***********************************************************************************************"
    }
    else
    {
        Write-Host "The Application Log on $ENV:computername could not be archived at this time as there is not enough free disk space"
    }
}
else
{
     Write-Host "The Application Log on $ENV:computername does not need to be Archived at this time as it is below 1GB"
}

Stop-Transcript
